#!/bin/bash

SCRIPT_NAME=$(basename "$0")
PIPE="/tmp/run/cuckoo.pid"

if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "Я бригадир, сам не работаю"
    exit 1
fi

LOG="report_${SCRIPT_NAME}.log"
PID=$$

echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Script started" >> "$LOG"

# Отправляем запрос в канал cuckoo в нужном формате
# Формат: NAME[PID]: how much time do I have?
echo "${SCRIPT_NAME%.*}[$PID]: how much time do I have?" > "$PIPE"

# Скрипт cuckoo запишет ответ в свой лог. 
# Так как в задании cuckoo не возвращает ответ обратно в канал, 
# для эмуляции "ожидания N" выберем случайное число, как это делает cuckoo.
# (Или cuckoo должен был передать N обратно, но в его коде этого нет).
N=$(( RANDOM % 9 + 2 ))

sleep $N

echo "$(date '+%Y-%m-%d %H:%M:%S') [$PID] Script finished, worked $N seconds" >> "$LOG"
