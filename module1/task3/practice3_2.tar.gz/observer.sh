#!/bin/bash

CONFIG="observer.conf"
LOG="observer.log"

if [ ! -f "$CONFIG" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') ERROR: $CONFIG not found" >> "$LOG"
    exit 1
fi

while IFS= read -r script || [[ -n "$script" ]]; do
    [[ -z "$script" ]] && continue

    if ! grep -qs "$script" /proc/[0-9]*/cmdline; then
        if [ -f "./$script" ]; then
            chmod +x "./$script"
            nohup "./$script" > /dev/null 2>&1 &
            echo "$(date '+%Y-%m-%d %H:%M:%S') Restarted: $script" >> "$LOG"
        else
            echo "$(date '+%Y-%m-%d %H:%M:%S') File not found: $script" >> "$LOG"
        fi
    fi
done < "$CONFIG"
